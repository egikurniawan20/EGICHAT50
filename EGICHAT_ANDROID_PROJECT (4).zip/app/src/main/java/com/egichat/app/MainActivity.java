package com.egichat.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PictureInPictureParams;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Rational;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;

public class MainActivity extends Activity {
    static volatile boolean visible = false;
    static volatile long callLaunchAt = 0;
    static final int REQ_FILE = 11, REQ_PERM = 12;
    static final String HOST = "appassets.androidplatform.net";

    WebView wv;
    ValueCallback<Uri[]> fileCb;
    volatile boolean videoCall = false;   /* sedang video call -> boleh ngambang (PiP) */

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wv = new WebView(this);
        setContentView(wv);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        wv.addJavascriptInterface(new Bridge(), "Android");

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { }
                return true;
            }
        });

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(new Runnable() {
                    public void run() { r.grant(r.getResources()); }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        askPerms();
        handleIntent(getIntent());
        wv.loadUrl("https://" + HOST + "/assets/index.html");
    }

    void handleIntent(Intent i) {
        if (i != null && i.getBooleanExtra("call", false)) {
            callLaunchAt = System.currentTimeMillis();
            if (Build.VERSION.SDK_INT >= 27) {
                setShowWhenLocked(true);
                setTurnScreenOn(true);
            } else {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
            }
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        visible = true;
        SharedPreferences p = getSharedPreferences("egi", 0);
        String uid = p.getString("uid", "");
        if (!uid.isEmpty()) {
            if (CallService.inst == null) startSvc();
            setupStep(p);
        }
    }

    @Override
    protected void onPause() {
        visible = false;
        super.onPause();
    }

    @Override
    protected void onStop() {
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(false);
        super.onStop();
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    /* ---------- kartu ngambang (Picture-in-Picture) seperti WhatsApp ---------- */
    PictureInPictureParams pipParams() {
        PictureInPictureParams.Builder b = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(9, 16));
        if (Build.VERSION.SDK_INT >= 31) {
            b.setAutoEnterEnabled(videoCall);      /* Android 12+: otomatis ngambang saat tekan Beranda */
            b.setSeamlessResizeEnabled(true);
        }
        return b.build();
    }

    void updatePip() {
        try { setPictureInPictureParams(pipParams()); } catch (Exception e) { }
    }

    void enterPipNow() {
        try {
            if (videoCall && !isInPictureInPictureMode()) enterPictureInPictureMode(pipParams());
        } catch (Exception e) { }
    }

    @Override
    protected void onUserLeaveHint() {            /* Android 8-11: tombol Beranda */
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT < 31) enterPipNow();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (wv != null) wv.evaluateJavascript("window.__nativePip&&window.__nativePip(" + inPip + ")", null);
    }

    void askPerms() {
        ArrayList<String> l = new ArrayList<String>();
        String[] want = {Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA};
        for (String w : want) {
            if (checkSelfPermission(w) != PackageManager.PERMISSION_GRANTED) l.add(w);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            l.add("android.permission.POST_NOTIFICATIONS");
        }
        if (!l.isEmpty()) {
            try { requestPermissions(l.toArray(new String[0]), REQ_PERM); } catch (Exception e) { }
        }
    }

    /* langkah sekali jalan: bebas hemat baterai, lalu izin notifikasi layar penuh (Android 14+) */
    void setupStep(SharedPreferences p) {
        try {
            if (!p.getBoolean("bat_asked", false)) {
                p.edit().putBoolean("bat_asked", true).apply();
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                    return;
                }
            }
            if (!p.getBoolean("fsi_asked", false)) {
                p.edit().putBoolean("fsi_asked", true).apply();
                if (Build.VERSION.SDK_INT >= 34) {
                    NotificationManager nm = getSystemService(NotificationManager.class);
                    if (!nm.canUseFullScreenIntent()) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName())));
                    }
                }
            }
        } catch (Exception e) { }
    }

    void startSvc() {
        try {
            Intent i = new Intent(this, CallService.class);
            startForegroundService(i);
        } catch (Exception e) { }
    }

    static int parseColor(String s) {
        s = s.trim();
        if (s.startsWith("rgb")) {
            String[] p = s.replaceAll("[^0-9.,]", "").split(",");
            return Color.rgb((int) Float.parseFloat(p[0]), (int) Float.parseFloat(p[1]), (int) Float.parseFloat(p[2]));
        }
        return Color.parseColor(s);
    }

    class Bridge {
        @JavascriptInterface
        public void setUser(String uid) {
            if (uid == null) uid = "";
            SharedPreferences p = getSharedPreferences("egi", 0);
            String old = p.getString("uid", "");
            if (!uid.equals(old)) p.edit().putString("uid", uid).apply();
            if (uid.isEmpty()) {
                stopService(new Intent(MainActivity.this, CallService.class));
                return;
            }
            if (CallService.inst == null && visible) startSvc();
        }

        @JavascriptInterface
        public void setInCall(boolean on, boolean video) {
            CallService.setCall(on, video);
            final boolean v = on && video;
            if (v != videoCall) {
                videoCall = v;
                runOnUiThread(new Runnable() { public void run() { updatePip(); } });
            }
        }

        @JavascriptInterface
        public void enterPip() {
            runOnUiThread(new Runnable() { public void run() { enterPipNow(); } });
        }

        @JavascriptInterface
        public boolean consumeCallLaunch() {
            boolean r = System.currentTimeMillis() - callLaunchAt < 90000 && callLaunchAt > 0;
            callLaunchAt = 0;
            return r;
        }

        @JavascriptInterface
        public void requestPermissions(String what) {
            runOnUiThread(new Runnable() { public void run() { askPerms(); } });
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(new Runnable() { public void run() { askPerms(); } });
        }

        @JavascriptInterface
        public void showNotification(String title, String body) {
            CallService.postInfo(MainActivity.this, title, body);
        }

        @JavascriptInterface
        public void cancelAllNotifications() {
            CallService.cancelInfo(MainActivity.this);
        }

        @JavascriptInterface
        public void setStatusBarColor(final String c) {
            runOnUiThread(new Runnable() {
                public void run() { try { getWindow().setStatusBarColor(parseColor(c)); } catch (Exception e) { } }
            });
        }

        @JavascriptInterface
        public void setNavigationBarColor(final String c) {
            runOnUiThread(new Runnable() {
                public void run() { try { getWindow().setNavigationBarColor(parseColor(c)); } catch (Exception e) { } }
            });
        }

        @JavascriptInterface
        public void setLightStatusBar(final boolean light) {
            runOnUiThread(new Runnable() {
                public void run() {
                    View d = getWindow().getDecorView();
                    int f = d.getSystemUiVisibility();
                    f = light ? (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                    d.setSystemUiVisibility(f);
                }
            });
        }

        @JavascriptInterface
        public void setLightNavigationBar(final boolean light) {
            runOnUiThread(new Runnable() {
                public void run() {
                    View d = getWindow().getDecorView();
                    int f = d.getSystemUiVisibility();
                    f = light ? (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                    d.setSystemUiVisibility(f);
                }
            });
        }
    }
}
