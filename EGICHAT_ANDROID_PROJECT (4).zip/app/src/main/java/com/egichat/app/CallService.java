package com.egichat.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.OffsetDateTime;
import java.util.HashSet;

/** Menunggu panggilan masuk di latar belakang (polling Supabase) dan menampilkan notifikasi layar penuh seperti WhatsApp. */
public class CallService extends Service {
    static final String SB = "https://nyfjmjyshomnhkkqeumd.supabase.co";
    static final String KEY = "sb_publishable_3kXnkZpfpq8hJUvJP4rr7A_BtwdzG4Q";
    static final String CH_SVC = "svc", CH_CALL = "call", CH_INFO = "info";
    static final int ID_FG = 1, ID_CALL = 2, ID_MISSED = 3, ID_INFO = 100;
    static final long RING_MS = 45000;

    static volatile CallService inst;
    static volatile boolean inCall = false, inVideo = false;

    volatile boolean running = false;
    Thread th;
    PowerManager.WakeLock wl;
    Ringtone ring;
    Vibrator vib;

    String uid = "";
    volatile String ringId, ringFrom, ringName;
    volatile long ringT;

    /* ---------- util ---------- */
    static void channels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel s = new NotificationChannel(CH_SVC, "Layanan EGI CHAT", NotificationManager.IMPORTANCE_LOW);
        s.setShowBadge(false);
        nm.createNotificationChannel(s);
        NotificationChannel k = new NotificationChannel(CH_CALL, "Panggilan masuk", NotificationManager.IMPORTANCE_HIGH);
        k.setSound(null, null);
        k.enableVibration(false);
        k.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(k);
        NotificationChannel i = new NotificationChannel(CH_INFO, "Pesan & info", NotificationManager.IMPORTANCE_HIGH);
        nm.createNotificationChannel(i);
    }

    static PendingIntent openApp(Context c, int rc, boolean call) {
        Intent o = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (call) o.putExtra("call", true);
        return PendingIntent.getActivity(c, rc, o, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void postInfo(Context c, String title, String body) {
        try {
            if (title == null) title = "";
            if (body == null) body = "";
            /* panggilan masuk & panggilan berlangsung sudah ditangani layanan ini */
            if (title.startsWith("Panggilan") && (title.contains("masuk") || title.contains("sedang berlangsung"))) return;
            channels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            int id = ID_INFO + (Math.abs(title.hashCode()) % 100000);
            Notification n = new Notification.Builder(c, CH_INFO)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setAutoCancel(true)
                    .setContentIntent(openApp(c, 5, false))
                    .build();
            nm.notify(id, n);
        } catch (Exception e) { }
    }

    static void cancelInfo(Context c) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            for (StatusBarNotification s : nm.getActiveNotifications()) {
                if (s.getId() >= ID_INFO) nm.cancel(s.getId());
            }
        } catch (Exception e) { }
    }

    static void setCall(boolean on, boolean video) {
        if (inCall == on && inVideo == video) return;
        inCall = on;
        inVideo = video;
        final CallService s = inst;
        if (s != null) new Handler(Looper.getMainLooper()).post(new Runnable() { public void run() { s.startFg(); } });
    }

    boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    NotificationManager nm() {
        return getSystemService(NotificationManager.class);
    }

    /* ---------- siklus layanan ---------- */
    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        channels(this);
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "egichat:poll");
            wl.acquire();
        } catch (Exception e) { }
        startFg();
    }

    void startFg() {
        Notification.Builder b = new Notification.Builder(this, CH_SVC)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(inCall ? "Panggilan sedang berlangsung" : "EGI CHAT aktif")
                .setContentText(inCall ? "Ketuk untuk kembali ke panggilan" : "Menunggu panggilan masuk")
                .setOngoing(true)
                .setContentIntent(openApp(this, 0, false));
        if (inCall) b.setCategory(Notification.CATEGORY_CALL);
        Notification n = b.build();

        int t = 0;
        if (Build.VERSION.SDK_INT >= 34) t = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
        int full = t;
        if (inCall && Build.VERSION.SDK_INT >= 30) {
            if (has("android.permission.RECORD_AUDIO")) full |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE;
            if (inVideo && has("android.permission.CAMERA")) full |= ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA;
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID_FG, n, full);
            else startForeground(ID_FG, n);
        } catch (Exception e) {
            try {
                if (Build.VERSION.SDK_INT >= 29) startForeground(ID_FG, n, t);
                else startForeground(ID_FG, n);
            } catch (Exception e2) { }
        }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        uid = getSharedPreferences("egi", 0).getString("uid", "");
        if (uid.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (th == null || !th.isAlive()) {
            running = true;
            th = new Thread(new Runnable() { public void run() { loop(); } }, "egi-poll");
            th.start();
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent i) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        inst = null;
        stopRing();
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) { }
        super.onDestroy();
    }

    /* ---------- polling sinyal ---------- */
    void loop() {
        String cur = "";
        long last = -1;
        while (running) {
            try {
                String u = getSharedPreferences("egi", 0).getString("uid", "");
                if (u.isEmpty()) { stopSelf(); break; }
                if (!u.equals(cur)) { cur = u; uid = u; last = -1; }
                String q = URLEncoder.encode(u, "UTF-8");
                if (last < 0) {
                    JSONArray a = new JSONArray(http("GET", "riichat_signals?to_uid=eq." + q + "&select=id&order=id.desc&limit=1", null));
                    last = a.length() > 0 ? a.getJSONObject(0).getLong("id") : 0;
                } else {
                    JSONArray a = new JSONArray(http("GET", "riichat_signals?to_uid=eq." + q + "&id=gt." + last + "&order=id.asc&limit=100", null));
                    HashSet<String> ended = new HashSet<String>();
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject r = a.getJSONObject(i);
                        String k = r.optString("kind");
                        if (k.equals("cancel") || k.equals("end")) ended.add(r.optString("call_id"));
                    }
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject r = a.getJSONObject(i);
                        last = Math.max(last, r.getLong("id"));
                        String k = r.optString("kind");
                        String cid = r.optString("call_id");
                        if (k.equals("invite")) {
                            if (!ended.contains(cid)) onInvite(r);
                        } else if (k.equals("cancel") || k.equals("end")) {
                            if (cid.equals(ringId)) endCall(true);
                        }
                    }
                }
            } catch (Exception e) {
                /* jaringan putus sesaat: coba lagi */
            }
            try {
                if (ringId != null) {
                    if (MainActivity.visible) endCall(false);
                    else if (System.currentTimeMillis() - ringT > RING_MS) endCall(true);
                }
            } catch (Exception e) { }
            try { Thread.sleep(ringId != null ? 1000 : 2000); } catch (InterruptedException e) { break; }
        }
    }

    void onInvite(JSONObject r) {
        if (MainActivity.visible) return;      /* aplikasi sedang dibuka: UI panggilan di dalam aplikasi yang menangani */
        if (ringId != null) return;
        /* abaikan sinyal basi (mis. jaringan baru pulih) */
        try {
            long age = System.currentTimeMillis() - OffsetDateTime.parse(r.optString("created_at")).toInstant().toEpochMilli();
            if (age > 40000) return;
        } catch (Exception e) { }
        String cid = r.optString("call_id"), from = r.optString("from_uid");
        JSONObject p = r.optJSONObject("payload");
        boolean video = p != null && p.optBoolean("video");
        String name = p != null ? p.optString("name", "") : "";
        if (name.isEmpty()) name = from;
        showCall(cid, from, name, video);
    }

    void showCall(String cid, String from, String name, boolean video) {
        ringId = cid; ringFrom = from; ringName = name; ringT = System.currentTimeMillis();
        PendingIntent open = openApp(this, 1, true);
        Intent rj = new Intent(this, Act.class).setAction("REJECT");
        PendingIntent rej = PendingIntent.getBroadcast(this, 2, rj, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CH_CALL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(video ? "Panggilan video masuk" : "Panggilan suara masuk")
                .setContentText(name)
                .setCategory(Notification.CATEGORY_CALL)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(RING_MS)
                .setFullScreenIntent(open, true)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Tolak", rej).build())
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Jawab", open).build());
        nm().notify(ID_CALL, b.build());
        startRing();
        postSig(cid, from, "ringing");   /* beri tahu penelepon bahwa HP ini sedang berdering */
    }

    synchronized void endCall(boolean missed) {
        if (ringId == null) return;
        String name = ringName;
        ringId = null;
        stopRing();
        nm().cancel(ID_CALL);
        if (missed) {
            Notification n = new Notification.Builder(this, CH_INFO)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("Panggilan tidak terjawab")
                    .setContentText(name)
                    .setAutoCancel(true)
                    .setContentIntent(openApp(this, 3, false))
                    .build();
            nm().notify(ID_MISSED, n);
        }
    }

    void reject() {
        String cid = ringId, from = ringFrom;
        endCall(false);
        if (cid != null) postSig(cid, from, "reject");
    }

    void startRing() {
        try {
            Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            ring = RingtoneManager.getRingtone(this, u);
            if (ring != null) {
                ring.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                if (Build.VERSION.SDK_INT >= 28) ring.setLooping(true);
                ring.play();
            }
        } catch (Exception e) { }
        try {
            vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pat = {0, 600, 400, 600, 1200};
            if (vib != null) vib.vibrate(VibrationEffect.createWaveform(pat, 0));
        } catch (Exception e) { }
    }

    void stopRing() {
        try { if (ring != null) ring.stop(); } catch (Exception e) { }
        ring = null;
        try { if (vib != null) vib.cancel(); } catch (Exception e) { }
    }

    void postSig(String cid, String to, String kind) {
        try {
            JSONObject o = new JSONObject();
            o.put("call_id", cid);
            o.put("from_uid", uid);
            o.put("to_uid", to);
            o.put("kind", kind);
            o.put("payload", JSONObject.NULL);
            http("POST", "riichat_signals", new JSONArray().put(o).toString());
        } catch (Exception e) { }
    }

    String http(String method, String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SB + "/rest/v1/" + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("apikey", KEY);
        c.setRequestProperty("Authorization", "Bearer " + KEY);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Prefer", "return=minimal");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.close();
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        if (is != null) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            is.close();
        }
        c.disconnect();
        if (code >= 400) throw new Exception("HTTP " + code);
        return bo.toString("UTF-8");
    }

    /* ---------- receiver ---------- */
    public static class Act extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            final CallService s = inst;
            if (s != null) new Thread(new Runnable() { public void run() { s.reject(); } }).start();
        }
    }

    public static class Boot extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            try {
                SharedPreferences p = c.getSharedPreferences("egi", 0);
                if (!p.getString("uid", "").isEmpty()) {
                    c.startForegroundService(new Intent(c, CallService.class));
                }
            } catch (Exception e) { }
        }
    }
}
