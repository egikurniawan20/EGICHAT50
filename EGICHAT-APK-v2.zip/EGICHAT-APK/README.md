# EGI CHAT - Project APK

Project Android (WebView) siap build lewat GitHub Actions. Halaman aplikasi ada di
`app/src/main/assets/index.html`.

## Cara membuat APK di GitHub
1. Buat repository baru di GitHub (boleh private).
2. Upload SELURUH isi folder ini (termasuk folder `.github`) ke repository, branch `main`.
3. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis setelah upload, atau klik **Run workflow**).
4. Tunggu centang hijau (sekitar 3-5 menit), buka run-nya, lalu unduh **EGICHAT-APK** di bagian *Artifacts*.
5. Ekstrak zip artifact -> `EGICHAT.apk` -> pasang di HP.

## Update aplikasi berikutnya
Ganti file `app/src/main/assets/index.html` dengan versi terbaru, commit, dan workflow akan membuat APK baru.

## Fitur native
- Picture-in-Picture sistem Android: saat video call tersambung lalu tekan Beranda, kartu video ngambang di atas aplikasi lain.
- Izin kamera & mikrofon, tombol speaker, pemilih file (kirim foto/video).
