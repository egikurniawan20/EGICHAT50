package com.egichat.app;

import android.Manifest;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * EGI CHAT - WebView penuh + jembatan "EgiNative" untuk video call:
 *  - Picture-in-Picture sistem Android (kartu ngambang) saat video call berjalan lalu tekan Beranda
 *  - izin kamera / mikrofon, speaker, pemilih file
 * Halaman dimuat dari assets/index.html lewat https://appassets.egichat.local/ (secure context -> getUserMedia jalan).
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.egichat.local";
    private static final int REQ_PERM = 101;
    private static final int REQ_FILE = 102;

    private WebView web;
    private volatile boolean videoCall = false;
    private boolean inPip = false;

    private ValueCallback<Uri[]> filePathCb;
    private PermissionRequest pendingWebPerm;
    private AudioManager audio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);

        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int initBar = night ? 0xFF111B21 : 0xFFFFFFFF;
        getWindow().setStatusBarColor(initBar);
        getWindow().setNavigationBarColor(initBar);
        if (Build.VERSION.SDK_INT >= 28) getWindow().setNavigationBarDividerColor(Color.TRANSPARENT);
        setBarIcons(true, !night);
        setBarIcons(false, !night);

        web = new WebView(this);
        web.setBackgroundColor(initBar);
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.setLayerType(WebView.LAYER_TYPE_HARDWARE, null);

        Bridge bridge = new Bridge();
        web.addJavascriptInterface(bridge, "EgiNative");
        web.addJavascriptInterface(bridge, "Android"); // nama yang dicari kode HTML untuk izin & speaker

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && HOST.equals(u.getHost())) {
                    String path = u.getPath();
                    if (path == null || path.equals("/") || path.isEmpty()) path = "/index.html";
                    try {
                        InputStream in = getAssets().open(path.substring(1));
                        return new WebResourceResponse(mimeFor(path), "utf-8", in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new java.util.HashMap<String, String>(), new java.io.ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u == null) return false;
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> handleWebPermission(request));
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("https://" + HOST + "/index.html");
        }
    }

    /** Ikon bar status / navigasi: light=true -> ikon gelap (untuk latar terang). */
    private void setBarIcons(boolean status, boolean light) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                int m = status ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                               : WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light ? m : 0, m);
            }
        } else {
            View d = getWindow().getDecorView();
            int f = d.getSystemUiVisibility();
            int m = status ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            d.setSystemUiVisibility(light ? (f | m) : (f & ~m));
        }
    }

    private void applyBarColor(boolean status, String hex) {
        try {
            int c = Color.parseColor(hex.trim());
            if (status) getWindow().setStatusBarColor(c);
            else getWindow().setNavigationBarColor(c);
        } catch (Exception ignored) {
        }
    }

    private static String mimeFor(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html") || p.endsWith(".htm")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".mp3")) return "audio/mpeg";
        if (p.endsWith(".ogg")) return "audio/ogg";
        if (p.endsWith(".wav")) return "audio/wav";
        return "application/octet-stream";
    }

    /* ---------------- izin kamera / mikrofon ---------------- */

    private List<String> missingFor(boolean cam, boolean mic) {
        List<String> need = new ArrayList<>();
        if (cam && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.CAMERA);
        if (mic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        return need;
    }

    private void handleWebPermission(PermissionRequest request) {
        boolean cam = false, mic = false;
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) cam = true;
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true;
        }
        List<String> need = missingFor(cam, mic);
        if (need.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingWebPerm != null) pendingWebPerm.deny();
            pendingWebPerm = request;
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERM || pendingWebPerm == null) return;
        boolean ok = results.length > 0;
        for (int r : results) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
        PermissionRequest req = pendingWebPerm;
        pendingWebPerm = null;
        if (ok) req.grant(req.getResources());
        else req.deny();
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == REQ_FILE && filePathCb != null) {
            filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            filePathCb = null;
        }
    }

    /* ---------------- Picture-in-Picture (kartu ngambang) ---------------- */

    private PictureInPictureParams pipParams() {
        PictureInPictureParams.Builder b = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(9, 16));
        if (Build.VERSION.SDK_INT >= 31) {
            b.setAutoEnterEnabled(videoCall);       // masuk PiP mulus saat gestur Beranda
            b.setSeamlessResizeEnabled(false);      // video: hindari tampilan terpotong/tergeser saat resize
        }
        return b.build();
    }

    private void refreshPipParams() {
        try {
            setPictureInPictureParams(pipParams());
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (videoCall && Build.VERSION.SDK_INT < 31 && !isInPictureInPictureMode()) {
            try {
                enterPictureInPictureMode(pipParams());
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (web != null) {
            web.evaluateJavascript("window.__nativePip&&window.__nativePip(" + isInPip + ")", null);
        }
    }

    /* ---------------- siklus hidup ---------------- */

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.resumeTimers();
        }
    }

    // WebView sengaja TIDAK di-pause saat ke latar belakang / PiP supaya panggilan & realtime tetap hidup.

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("EgiNative");
            web.removeJavascriptInterface("Android");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /* ---------------- jembatan ke JavaScript ---------------- */

    public class Bridge {
        /** Dipanggil halaman: true saat video call tersambung. */
        @JavascriptInterface
        public void setVideoCall(final boolean on) {
            videoCall = on;
            runOnUiThread(() -> {
                refreshPipParams();
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        /** Dipanggil halaman sebelum mengambil kamera/mikrofon: 'camera,microphone' atau 'microphone'. */
        @JavascriptInterface
        public void requestPermissions(final String what) {
            final boolean cam = what != null && what.contains("camera");
            runOnUiThread(() -> {
                List<String> need = missingFor(cam, true);
                if (!need.isEmpty()) MainActivity.this.requestPermissions(need.toArray(new String[0]), REQ_PERM + 1);
            });
        }

        @JavascriptInterface
        public void requestMediaPermission(final boolean video) {
            requestPermissions(video ? "camera,microphone" : "microphone");
        }

        /* Warna bar atas & bawah mengikuti tema aplikasi (nama method cocok dengan yang dicari kode HTML) */
        @JavascriptInterface
        public void setStatusBarColor(final String hex) {
            runOnUiThread(() -> applyBarColor(true, hex));
        }

        @JavascriptInterface
        public void setNavigationBarColor(final String hex) {
            runOnUiThread(() -> applyBarColor(false, hex));
        }

        @JavascriptInterface
        public void setLightStatusBar(final boolean light) {
            runOnUiThread(() -> setBarIcons(true, light));
        }

        @JavascriptInterface
        public void setLightNavigationBar(final boolean light) {
            runOnUiThread(() -> setBarIcons(false, light));
        }

        /** Speaker (true) / earpiece (false). Nama cocok dengan pola yang dicari kode HTML. */
        @JavascriptInterface
        public void setSpeakerphone(final boolean on) {
            try {
                audio.setMode(AudioManager.MODE_IN_COMMUNICATION);
                audio.setSpeakerphoneOn(on);
            } catch (Exception ignored) {
            }
        }
    }
}
